export interface Properties {
    [propertyName: string]: any;
}
export declare const getAgGridProperties: () => [Properties, Properties, {}];
